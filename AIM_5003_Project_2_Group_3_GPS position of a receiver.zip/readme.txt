
1) For each activity, there is one script file. So, total there are 5 script files, one each for activity 1, 2,4,5,6. Script files are titled as  'activity <no.>.ipynb'
2) one script file titled as References.ipynb has references.
3) project report is in PDF format.
4) following steps are required for each activity file (jupyter notebook) before executing first/any cell:
	install/install the libraries as mentioned in the first cell 
	import particular package from the library as mentioned in the first cell
	Once first cell is executed successfully (no error pops up), go to <Kernel> tab in the menu bar -> select <Restart & Run All> from the available option -> in the pop up box click <Restart and Run All Cells> -> wait for few seconds/minutes (depend on your system configuration) -> the whole file will generate output cells and you can scroll down and check the calculations or scripts.
	
	